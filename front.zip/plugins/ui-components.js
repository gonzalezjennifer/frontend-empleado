import Vue from 'vue'

import uiAlert from '~/components/ui/uiAlert.vue'

Vue.component('UiAlert', uiAlert)
