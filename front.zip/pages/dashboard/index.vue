<template>
  <div>
    Dashboard
  </div>
</template>

<script>
export default {
  // middleware: 'auth'
  auth: true
}
</script>

<style scoped>

</style>
