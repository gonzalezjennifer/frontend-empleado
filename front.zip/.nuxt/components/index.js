export { default as EmpleadosBorrarEmpleado } from '../..\\components\\empleados\\borrarEmpleado.vue'
export { default as EmpleadosCrearEmpleado } from '../..\\components\\empleados\\crearEmpleado.vue'
export { default as EmpleadosLoginCard } from '../..\\components\\empleados\\loginCard.vue'
export { default as UiAlert } from '../..\\components\\ui\\uiAlert.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
